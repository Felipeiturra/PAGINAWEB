
<?php
session_start();

if (isset($_SESSION['nombre_de_usuario'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombreDeUsuario = $_POST['nombre_de_usuario'];
    $contrasena = $_POST['contrasena'];

    include("con_db.php");
    $conex = conectar();

    $consulta = "SELECT * FROM cliente_usuario WHERE nombre_de_usuario = ? AND contrasena = ?";
    $stmt = mysqli_prepare($conex, $consulta);
    mysqli_stmt_bind_param($stmt, "ss", $nombreDeUsuario, $contrasena);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) == 1) {
        $_SESSION['nombre_de_usuario'] = $nombreDeUsuario;
        header("Location: menu.html");
        exit;
    } else {
        $error_message = "Usuario o contraseña incorrectos";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Elevate Threads</title>
    <link rel="stylesheet" href="../css/stylelogin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
    <link rel="icon" href="../img/ico.webp">
</head>

<body>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-box animated fadeInUp">
        <h1 class="form-title">INICIO SESION</h1>
        <input type="text" name="nombre_de_usuario" placeholder="Nombre de Usuario" autofocus required>
        <input type="password" name="contrasena" placeholder="Contraseña" required>
        <button type="submit">Login</button>
        <a href="../src/formregistrar.php">Crea una cuenta aquí</a>
        <br>
        <br>
        <a href="indexloginadmin.php">Iniciar Sesión Administrador</a>
        <br>
        <br>
        <div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
        <?php if (isset($error_message)) : ?>
            <p><?php echo $error_message; ?></p>
        <?php endif; ?>
    </form>
</body>

</html>
