<?php session_start();

if(isset($_SESSION['carrito'])){
    $carrito_mio=$_SESSION['carrito'];
    if(isset($_POST['titulo'])){
        $titulo=$_POST['titulo'];
        $precio=$_POST['precio'];
        $cantidad=$_POST['cantidad'];
        $num=0;
        $carrito_mio[]=array("titulo"=>$titulo,"precio"=>$precio,"cantidad"=>$cantidad);

        // Insertar en la tabla producto_has_venta
        $sql = "INSERT INTO producto_has_venta (id_producto, id_venta, cantidad) VALUES ((SELECT id_producto FROM producto WHERE nombre = '$titulo'), (SELECT MAX(id_venta) FROM venta), '$cantidad')";
        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}else{
    $titulo=$_POST['titulo'];
    $precio=$_POST['precio'];
    $cantidad=$_POST['cantidad'];
    $carrito_mio[]=array("titulo"=>$titulo,"precio"=>$precio,"cantidad"=>$cantidad);   
}

$_SESSION['carrito']=$carrito_mio;

$conn->close();

header("Location: ".$_SERVER['HTTP_REFERER']."");
?>







