<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Elevate Threads</title>
    <link rel="stylesheet" href="../css/stylelogin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
    <link rel="icon" href="../img/ico.webp">

</head>

<body>
    <?php
    session_start();

  
    if (isset($_SESSION['name'])) {
     
        header("Location: index.php");
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        $name = $_POST['name'];
        $password = $_POST['password'];

    
        include("con_db.php");
        $conex = conectar();

        $consulta = "SELECT * FROM administradores  WHERE name = '$name' AND password = '$password'";
        $resultado = mysqli_query($conex, $consulta);

        if (mysqli_num_rows($resultado) == 1) {
      
            $_SESSION['name'] = $name;
            
            header("Location: menuAdmin.html");
            exit;
        } else {
   
            $error_message = "Usuario o contraseña incorrectos";
        }
    }
    ?>

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="form-box animated fadeInUp">
        <h1 class="form-title">INICIO SESION ADMINISTRADOR</h1>
        <input type="text" name="name" placeholder="Username" autofocus required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
      
        <div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>

        <?php if (isset($error_message)) : ?>
            <p><?php echo $error_message; ?></p>
        <?php endif; ?>
    </form>
</body>

</html>
