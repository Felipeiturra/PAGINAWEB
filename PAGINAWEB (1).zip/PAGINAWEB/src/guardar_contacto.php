<?php
include('con_db.php'); 

$nombre = $_POST['nombre'];
$email = $_POST['email'];
$mensaje = $_POST['mensaje'];

$con = conectar();

$sql = "INSERT INTO cliente_usuario (nombre, correo_electronico, direccion, telefono) VALUES ('$nombre', '$email', '$mensaje', '123456789')";

if(mysqli_query($con, $sql)) {
    echo "El mensaje ha sido enviado correctamente.";
} else {
    echo "Error al enviar el mensaje: " . mysqli_error($con);
}

mysqli_close($con);

session_start();

setcookie("PHPSESSID", "", time() - 3600, "/");
header("refresh:2; url=../index.html");
exit;

session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<button onclick="window.location.href = 'menu.html'">VOLVER MENU</button><br>
    
</body>
</html>




