<?php


include 'con_db.php'; 

$con = conectar();

if (isset($_POST['id']) && isset($_POST['stock'])) {
    $id = $_POST['id'];
    $stock = $_POST['stock'];
    $sin_stock = isset($_POST['sin_stock']) ? 1 : 0;

    $query = "UPDATE mis_productos SET stock = stock + $stock, sin_stock = $sin_stock WHERE id = $id";

    $resultado = mysqli_query($con, $query); 

    if ($resultado) {
        echo "Producto actualizado correctamente";
    } else {
        echo "Error al actualizar el producto";
    }
} else {
    echo "Faltan datos para actualizar el producto";
}

mysqli_close($con); 
?>

