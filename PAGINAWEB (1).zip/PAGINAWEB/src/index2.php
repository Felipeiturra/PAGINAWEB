<?php
include 'con_db.php';
$con = conectar();

if (isset($_GET['categoria']) && !empty($_GET['categoria'])) {
    $categoria_id = $_GET['categoria'];
    $query = $con->query("SELECT * FROM producto WHERE id_categoria = $categoria_id ORDER BY id_producto DESC LIMIT 10");
} else {
    $query = $con->query("SELECT * FROM producto ORDER BY id_producto DESC LIMIT 10");
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <title>Carrito de Compras</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
           .container {
            padding: 20px;
        }

        .cart-link {
            width: 100%;
            text-align: right;
            display: block;
            font-size: 22px;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
  
         
            background-image:  url('../img/1.jpg');
            background-repeat: no-repeat;
            background-size: cover;
        }
        .item {
        width: 33.33%;
        float: left;
        box-sizing: border-box;
        padding: 10px;
    }

    .thumbnail {
        background-color: #f9f9f9;
        padding: 10px;
        text-align: center;
    }

    .thumbnail img {
        width: 100%;
        height: auto;
        margin-bottom: 10px;
    }

    .list-group-item-heading {
        font-size: 18px;
        margin-top: 0;
        margin-bottom: 10px;
    }

    .list-group-item-text {
        margin-bottom: 10px;
    }

    .lead {
        font-size: 16px;
        font-weight: bold;
    }

    .btn {
        font-size: 14px;
    }
    .button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }
        .alerta-roja {
            background-color: #ff9999;
        }
    </style>
</head>

<body>
    <div class="container">
        <form method="get" action="index2.php">
            <label for="categoria">Filtrar por Categoria:</label>
            <select name="categoria" id="categoria">
                <option value="">Todas las categorias</option>
                <?php
                $categorias_query = $con->query("SELECT * FROM categoria");
                while ($categoria = $categorias_query->fetch_assoc()) {
                    echo '<option value="' . $categoria["id_categoria"] . '">' . $categoria["nombre"] . '</option>';
                }
                ?>
            </select>
            <input type="submit" value="Filtrar">
        </form>

        <div id="products" class="row list-group">
            <?php
            if ($query->num_rows > 0) {
                while ($row = $query->fetch_assoc()) {
                    $stock_class = ($row["cantidad_de_inventario"] < 10) ? 'alerta-roja' : '';
                    $stock_comment = ($row["cantidad_de_inventario"] < 10) ? 'Quedan pocas unidades de este producto.' : '';

                    ?>
                    <div class="item col-lg-4 <?php echo $stock_class; ?>">
                        <div class="thumbnail">
                            <img src="<?php echo $row["image_url"]; ?>" alt="<?php echo $row["nombre"]; ?>" class="img-responsive">
                            <div class="caption">
                                <h4 class="list-group-item-heading">
                                    <?php echo $row["nombre"]; ?>
                                </h4>
                                <p class="list-group-item-text">
                                    <?php echo $row["descripcion"]; ?>
                                </p>
                                <p><?php echo $stock_comment; ?></p>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p class="lead">
                                            <?php echo '$' . $row["precio"] . ' CLP'; ?>
                                        </p>
                                    </div>
                                    <div class="col-md-6">
                                        <a class="button"
                                            href="AccionCarta.php?action=addToCart&id=<?php echo $row["id_producto"]; ?>">Enviar al Carrito</a>
                                    </div>
                                </div>
                                <p>Stock: <?php echo $row["cantidad_de_inventario"]; ?></p>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            } else {
                ?>
                <p>Producto(s) no existe.....</p>
                <?php
            }
            ?>
        </div>
        <div class="button-container">
            <a class="button" href="javascript:history.go(-1)">Volver</a>
        </div>
    </div>
</body>

</html>
