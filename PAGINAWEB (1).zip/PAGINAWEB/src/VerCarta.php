<?php

include 'La-carta.php';
$cart = new Cart;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Carrito de compras</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/vercarta.css"> <!-- Enlazar tu nuevo archivo CSS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
          .button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }
        .container {
            padding: 20px;
        }

        input[type="number"] {
            width: 20%;
        }

  
    </style>
    <script>
        function updateCartItem(obj, id) {
            $.get("cartAction.php", {
                action: "updateCartItem",
                id: id,
                qty: obj.value
            }, function (data) {
                if (data == 'ok') {
                    location.reload();
                } else {
                    alert('Cart update failed, please try again.');
                }
            });
        }
    </script>
</head>
</head>

<body>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">

                <ul class="nav nav-pills">
                    <li role="presentation"><a href="index2.php">Inicio</a></li>
                    <li role="presentation" class="active"><a href="VerCarta.php">Carrito de Compras</a></li>
                    <li role="presentation"><a href="Pagos.php">Pagar</a></li>

                </ul>
            </div>

            <div class="panel-body">


                <h1>Carrito de compras</h1>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Sub total</th>
                            <th>&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($cart->total_items() > 0) {
                          
                            $cartItems = $cart->contents();
                            foreach ($cartItems as $item) {
                                ?>
                                <tr>
                                    <td>
                                        <?php echo $item["name"]; ?>
                                    </td>
                                    <td>
                                        <?php echo '$' . $item["price"] . ' Clp'; ?>
                                    </td>
                                    <td><input type="number" class="form-control text-center bigger-input"
                                            value="<?php echo $item["qty"]; ?>"
                                            onchange="updateCartItem(this, '<?php echo $item["rowid"]; ?>')"></td>
                                    <td>
                                        <?php echo '$' . $item["subtotal"] . ' Clp'; ?>
                                    </td>
                                    <td>
                                        <a href="AccionCarta.php?action=removeCartItem&id=<?php echo $item["rowid"]; ?>"
                                            class="btn btn-danger" onclick="return confirm('Confirma eliminar?')"><i
                                                class="glyphicon glyphicon-trash"></i></a>
                                    </td>
                                </tr>
                            <?php }
                        } else { ?>
                            <tr>
                                <td colspan="5">
                                    <p>No has solicitado ning�n producto.....</p>
                                </td>
                            <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td><a href="index2.php" class="button"><i
                                        class="glyphicon glyphicon-menu-left"></i> Volver a la tienda</a></td>
                            <td colspan="2"></td>
                            <?php if ($cart->total_items() > 0) { ?>
                                <td class="text-center"><strong>Total
                                        <?php echo '$' . $cart->total() . ' Clp'; ?>
                                    </strong></td>
                                <td><a href="Pagos.php" class="button">Pagos <i
                                            class="glyphicon glyphicon-menu-right"></i></a></td>
                            <?php } ?>
                        </tr>
                    </tfoot>
                </table>

            </div>

       

        </div>
</body>
<div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
</html>