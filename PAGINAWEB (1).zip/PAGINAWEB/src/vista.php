<?php
include('con_db.php');
$con = conectar();

$queryOrden = "SELECT * FROM orden";
$resultadoOrden = $con->query($queryOrden);

$queryConteoClientes = "SELECT COUNT(*) AS total_clientes FROM cliente_usuario";
$resultadoConteoClientes = $con->query($queryConteoClientes);

$totalClientes = 0;

if ($resultadoConteoClientes && $resultadoConteoClientes->num_rows > 0) {
  $filaConteoClientes = $resultadoConteoClientes->fetch_assoc();
  $totalClientes = $filaConteoClientes['total_clientes'];
}
?>

<!DOCTYPE html>
<html>

<head>
  <style>
    html, body {
      height: 100%;
      margin: 0;
      padding: 0;
      font-family: sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      background: linear-gradient(to top, #3b1bf0, #080808); /* Degradado azul pastel hacia arriba */
      color: #ffffff;
    }

    .container {
      width: 80%;
      max-width: 800px;
      text-align: center;
    }

    h2 {
      text-transform: uppercase;
      font-weight: 500;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 10px;
      border-bottom: 1px solid #ffffff;
    }

    th {
      background-color: rgba(31, 63, 247, 0.75);
    }

    tbody tr:nth-child(even) {
      background-color: rgba(31, 63, 247, 0.25);
    }

    p {
      margin-top: 20px;
    }

    .btn-container {
      margin-top: 20px;
    }

    .btn {
      border: 0;
      background-color: rgba(31, 63, 247, 0.75);
      padding: 14px 40px;
      color: #ffffff;
      border-radius: 24px;
      transition: 0.25s;
      cursor: pointer;
    }

    .btn:hover {
      background-color: rgba(31, 63, 247, 1);
    }

    .button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }
  </style>
</head>

<body>
  <div class="container">
    <h2>Visualización de Ventas</h2>
    <?php if ($resultadoOrden && $resultadoOrden->num_rows > 0): ?>
      <table>
        <thead>
          <tr>
            <th>ID Orden</th> 
            <th>ID Cliente</th> <!-- Asegúrate de cambiar este encabezado si es necesario -->
            <th>Total</th> 
            <th>Creado</th> 
            <th>Modificado</th> 
          </tr>
        </thead>
        <tbody>
          <?php while ($filaOrden = $resultadoOrden->fetch_assoc()): ?>
            <tr>
              <td><?php echo $filaOrden['id']; ?></td>
              <td><?php echo $filaOrden['customer_id']; ?></td> <!-- Asegúrate de cambiar este nombre de columna si es necesario -->
              <td><?php echo $filaOrden['total_price']; ?></td>
              <td><?php echo $filaOrden['created']; ?></td>
              <td><?php echo $filaOrden['modified']; ?></td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    <?php else: ?>
      <p>No hay órdenes registradas</p>
    <?php endif; ?>
  </div>
  <div class="btn-container">
    <p>Total de clientes: <?php echo $totalClientes; ?></p>
    <h2>Conteo de Clientes</h2>
    <button class="btn" onclick="window.location.href = 'contventas.php'">VENTAS</button>
    <div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
  </div>
</body>

</html>
