<?php
session_start();

setcookie("PHPSESSID", "", time() - 3600, "/"); 
header("refresh:0; url=../index.html");
exit; 

session_destroy();
