<?php
date_default_timezone_set("America/Santiago");

include 'La-carta.php';
$cart = new Cart;

include 'con_db.php';
$con = conectar();

if (isset($_REQUEST['action']) && !empty($_REQUEST['action'])) {
    if ($_REQUEST['action'] == 'addToCart' && !empty($_REQUEST['id'])) {
        $productID = $_REQUEST['id'];
        $query = $con->query("SELECT * FROM producto WHERE id_producto = " . $productID);
        $row = $query->fetch_assoc();

        // Verifica si el producto existe en la base de datos
        if ($row) {
            $itemData = array(
                'id' => $row['id_producto'],
                'name' => $row['nombre'],
                'price' => $row['precio'],
                'qty' => 1
            );

            $insertItem = $cart->insert($itemData);
            $redirectLoc = $insertItem ? 'VerCarta.php' : 'index2.php';
            header("Location: " . $redirectLoc);
        } else {
            // Producto no encontrado, redirige a la página de inicio
            header("Location: index2.php");
        }
    } elseif ($_REQUEST['action'] == 'updateCartItem' && !empty($_REQUEST['id']) && !empty($_REQUEST['qty'])) {
        $itemData = array(
            'rowid' => $_REQUEST['id_producto'],
            'qty' => $_REQUEST['qty']
        );
        $updateItem = $cart->update($itemData);
        echo $updateItem ? 'ok' : 'err';
        die;
    } elseif ($_REQUEST['action'] == 'removeCartItem' && !empty($_REQUEST['id'])) {
        $deleteItem = $cart->remove($_REQUEST['id']);
        header("Location: VerCarta.php");
    } elseif ($_REQUEST['action'] == 'placeOrder' && $cart->total_items() > 0 && !empty($_SESSION['nombre_de_usuario'])) {
        $customerID = $_SESSION['nombre_de_usuario'];
        $totalPrice = $cart->total();
        $currentTime = date("Y-m-d H:i:s");

        // Prepara la consulta para insertar la orden en la tabla 'orden'
        $insertOrderQuery = $con->prepare("INSERT INTO orden (customer_id, total_price, created, modified) VALUES (?, ?, ?, ?)");
        $insertOrderQuery->bind_param("siss", $customerID, $totalPrice, $currentTime, $currentTime);

        if ($insertOrderQuery->execute()) {
            $orderID = $con->insert_id;
            $insertOrderQuery->close();


            // Cierra la consulta
    

            // Limpia el carrito después de realizar la orden
            $cart->destroy();

            // Redirige a la página de éxito de la orden con el ID de la orden
            header("Location: OrdenExito.php?id=$orderID");
            exit();
        } else {
            // Error al insertar la orden, redirige a la página de pago
            $insertOrderQuery->close();
            header("Location: Pagos.php");
            exit();
        }
    } else {
        // Acción no válida o datos insuficientes, redirige a la página de inicio
        header("Location: error.php");
        exit();
    }
} else {
    // No hay acción especificada, redirige a la página de inicio
    header("Location: index2.php");
    exit();
}
?>
