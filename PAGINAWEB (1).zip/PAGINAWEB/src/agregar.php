<?php
include 'con_db.php';

$con = conectar();

$nombre = $_POST['name'];
$descripcion = $_POST['description'];
$precio = $_POST['price'];
$cantidadDeInventario = $_POST['stock'];
$nombreCategoria = $_POST['categoria']; // Nuevo campo de categoría

// Obtener el id_categoria correspondiente al nombre de la categoría
$queryCategoria = "SELECT id_categoria FROM categoria WHERE nombre = ?";
$stmtCategoria = mysqli_prepare($con, $queryCategoria);
mysqli_stmt_bind_param($stmtCategoria, "s", $nombreCategoria);
mysqli_stmt_execute($stmtCategoria);
mysqli_stmt_bind_result($stmtCategoria, $idCategoria);
mysqli_stmt_fetch($stmtCategoria);
mysqli_stmt_close($stmtCategoria);

// Consulta preparada para prevenir inyecciones SQL
$query = "INSERT INTO producto (nombre, descripcion, precio, cantidad_de_inventario, id_categoria) VALUES (?, ?, ?, ?, ?)";
$stmt = mysqli_prepare($con, $query);
mysqli_stmt_bind_param($stmt, "ssdii", $nombre, $descripcion, $precio, $cantidadDeInventario, $idCategoria);

if (mysqli_stmt_execute($stmt)) {
    echo "Producto agregado correctamente";
} else {
    echo "Error al agregar el producto: " . mysqli_error($con);
}

mysqli_stmt_close($stmt);
mysqli_close($con);
?>
