<!DOCTYPE html>
<html>
<head>
    <title>Error de Conexión</title>
    <style>
        body {
            background: linear-gradient(to top, #3b1bf0, #080808); /* Degradado azul pastel hacia arriba */
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            color: white;
            font-family: Arial, sans-serif;
        }
        .error-message {
            text-align: center;
            margin-bottom: 20px;
        }
        .button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="error-message">
        <h1>Lo sentimos, el sistema no está disponible en este momento.</h1>
        <p>Por favor, inténtelo de nuevo más tarde.</p>
    </div>
    <div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
</body>
</html>
