<?php
include 'con_db.php';
$con = conectar();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <title>Carrito de Compras</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .container {
            padding: 20px;
        }

        .cart-link {
            width: 100%;
            text-align: right;
            display: block;
            font-size: 22px;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
          
            background-image:  url('../img/1.jpg');
            background-repeat: no-repeat;
            background-size: cover;
        }
   
    .item {
        width: 33.33%;
        float: left;
        box-sizing: border-box;
        padding: 10px;
    }

    .thumbnail {
        background-color: #f9f9f9;
        padding: 10px;
        text-align: center;
    }

    .thumbnail img {
        width: 100%;
        height: auto;
        margin-bottom: 10px;
    }

    .list-group-item-heading {
        font-size: 18px;
        margin-top: 0;
        margin-bottom: 10px;
    }

    .list-group-item-text {
        margin-bottom: 10px;
    }

    .lead {
        font-size: 16px;
        font-weight: bold;
    }

    .btn {
        font-size: 14px;
    }
    .button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }
        
    </style>
</head>
</head>

<body>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">

                <ul class="nav nav-pills">
                    <li role="presentation" class="active"><a href="index2.php">Inicio</a></li>
                   

                </ul>
            </div>

            <div class="panel-body">
                <h1>Tienda de Productos</h1>
                <a href="" class="cart-link" title="Ver Carta"><i
                        class="glyphicon glyphicon-shopping-cart"></i></a>
                <div id="products" class="row list-group">
                    <?php
                  
                    $query = $con->query("SELECT * FROM producto ORDER BY id_producto DESC LIMIT 10");
                    if ($query->num_rows > 0) {
                        while ($row = $query->fetch_assoc()) {
                            ?>
                            <div class="item col-lg-4">
    <div class="thumbnail">
        <img src="<?php echo $row["image_url"]; ?>" alt="<?php echo $row["nombre"]; ?>" class="img-responsive">
        <div class="caption">
            <h4 class="list-group-item-heading">
                <?php echo $row["nombre"]; ?>
            </h4>
            <p class="list-group-item-text">
                <?php echo $row["descripcion"]; ?>
            </p>
            <div class="row">
                <div class="col-md-6">
                    <p class="lead">
                        <?php echo '$' . $row["precio"] . ' CLP'; ?>
                    </p>
                </div>
                <div class="col-md-6">
                    <a class="btn btn-success" href="index.php">Enviar al Carrito</a>
                </div>
            </div>
        </div>
    </div>
</div>

                            
                        <?php }
                    } else { ?>
                        <p>Producto(s) no existe.....</p>
                    <?php } ?>
                </div>
            </div>
        </div>

</body>
<div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
</html>