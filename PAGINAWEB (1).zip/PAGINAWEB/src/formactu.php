<?php
include('con_db.php');
$con = conectar();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $stock = $_POST['stock'];
    $sinStock = isset($_POST['sin_stock']) ? 1 : 0;

    // Actualizar la cantidad de inventario del producto
    $queryActualizar = "UPDATE producto SET cantidad_de_inventario = cantidad_de_inventario + '$stock', sin_stock = '$sinStock' WHERE id_producto = '$id'";
    $resultadoActualizar = mysqli_query($con, $queryActualizar);

    if ($resultadoActualizar) {
     
        echo '<script>alert("Producto actualizado correctamente");</script>';
    } else {
        echo '<script>alert("Error al actualizar el producto ' . mysqli_error($con) . '");</script>';
    }
}
?>

<html>
<head>
    <title>Actualizar productos</title>
    <link rel="stylesheet" href="../css/formactu.css">
    <style>
           .button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="admin-container">

        <!-- Tu tabla de productos aquí -->
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

    <form action="" method="post">
        

        <h1>Actualizar productos</h1>
        <label for="id">ID del producto:</label>
        <input type="number" name="id" required><br><br>
        <label for="stock">Agregar stock:</label>
        <input type="number" name="stock" min="0" required><br><br>
        <label for="sin_stock">Marcar como sin stock:</label>
        <input type="checkbox" name="sin_stock" value="1"><br><br>
        <input type="submit" value="Actualizar">
        <div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
    </form>
</body>
</html>
