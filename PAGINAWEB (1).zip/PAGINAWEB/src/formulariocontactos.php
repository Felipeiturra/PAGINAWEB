<!DOCTYPE html>
<html>

<head>
	<title>Formulario de Contacto</title>
	<link rel="stylesheet" href="../css/formcontac.css">
	<link rel="icon" href="../img/ico.webp">
<style>
    body {
        background: linear-gradient(to top, #3b1bf0, #080808); /* Degradado azul pastel hacia arriba */
    }

    form {
        max-width: 400px;
        margin: 0 auto;
        background-color: #FFFFFF; /* Blanco */
        padding: 20px;
        border-radius: 4px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    label {
        display: block;
        margin-bottom: 10px;
        font-size: 16px;
        color: #000; /* Negro */
    }

    input[type="number"],
    input[type="checkbox"] {
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        font-size: 14px;
        transition: border-color 0.3s ease;
    }

    input[type="number"]:focus,
    input[type="checkbox"]:focus {
        border-color: #66afe9;
        outline: none;
    }

    input[type="submit"] {
        padding: 10px 20px;
        background-color: #0000FF; /* Azul */
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    input[type="submit"]:hover {
        background-color: #D4AF37; /* Dorado */
    }

    .button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }
</style>
</head>

<body>

			<form method="POST" action="guardar_contacto.php" class="form-box">
			<h2 class="form-title">ENVIAR SU FORMULARIO</h2>
				<input type="text" id="nombre" name="nombre" placeholder="INGRESE NOMBRE">
				<input type="email" id="email" name="email" placeholder="INGRESE EMAIL">
                 <p class="text-1">MENSAJE</p>
				<textarea id="mensaje" name="mensaje"></textarea>
				<input class="btnn" type="submit" value="Enviar">
                <div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
			</form>
			


		
</body>

</html>