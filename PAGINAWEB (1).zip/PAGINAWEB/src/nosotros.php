<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <title>Quienes Somos</title>
  <link rel="stylesheet" href="../css/nosotros.css">
  <link rel="icon" href="../img/ico.webp">
  <style>body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 0;
  background-image: linear-gradient(to bottom, #0000FF, #000000);
}

header {
  background-color: #000000;
  color: #0000FF;
  padding: 20px;
  text-align: center;
}
body {
  color: white;
}

nav ul li a {
  color: #0000FF;
}

.container {
  background-color:    #080808;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.5);
}

footer {
  background-color: #000000;
  color: #fff;
}
.button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }

  .btn{
    color: #0055ff;
  }</style>
</head>

<body>
  <header>
    <h1>Elevate threads</h1>
    <div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
    <nav>
      <ul>

      </ul>
    </nav>
  </header>
  <section class="content">
    <div class="container">
      <h2>QUIENES SOMOS</h2>
      <p>Nuestra empresa de ropa de calidad nació como una pequeña empresa con la visión de brindar prendas y accesorios de alta calidad que reflejen la elegancia y el estilo. Desde nuestros humildes comienzos, hemos estado comprometidos con la innovación y la excelencia en el servicio al cliente. Nuestra misión es satisfacer las necesidades de moda de nuestros clientes, ofreciendo productos y servicios excepcionales mientras mantenemos un fuerte enfoque en la sostenibilidad y la responsabilidad social.</p>
    </div>
  </section>
  <section class="content">
    <div class="container">
      <h2>VISION</h2>
      <p>Como una empresa de moda en crecimiento, reconocemos que la implementación de un sistema de gestión de ventas eficiente es fundamental. Esto nos permitirá mejorar la eficiencia y productividad de la empresa, optimizar nuestros procesos de venta y tomar decisiones estratégicas fundamentadas. La automatización de tareas, la comunicación efectiva dentro de nuestro equipo y la identificación de tendencias de moda nos ayudarán a expandir nuestro alcance a nivel mundial y a consolidarnos como líderes en la industria.</p>
  </section>
  <section class="content">
    <div class="container">
      <h2>MISION</h2>
      <p>Nuestra misión es impulsar el crecimiento sostenible de la empresa mediante la implementación de una estrategia de marketing digital efectiva. Nos esforzamos por mejorar la gestión y control de las ventas, suscripciones y productos ofrecidos. Además, estamos comprometidos en enriquecer la experiencia del cliente a través de un sitio web de primera calidad que refleje nuestra pasión por la moda y la calidad. Estamos decididos a llevar nuestros productos a los amantes de la moda de todo el mundo.</p>
    </div>
  </section>

  <footer>
    <p>&copy; 2023 Nuestra Empresa de Moda. Todos los derechos reservados.</p>
  </footer>
</body>


</html>