<?php

include('con_db.php'); 


$con = conectar();


$sql = "SELECT * FROM contactos";


$resultado = mysqli_query($con, $sql);

echo "<h2>Contactos:</h2>";
echo "<ul>";
while($fila = mysqli_fetch_array($resultado)) {
   
    $respondido = $fila['respondido'];
    if($respondido == 1) {
        $estado = "Respondido";
        $color = "green";
    } else {
        $estado = "Por responder";
        $color = "red";
    }
    
   
	echo "<li><strong>Nombre:</strong> " . $fila['nombre'] . " - <strong>Email:</strong> " . $fila['email'] . " - <strong>Mensaje:</strong> " . $fila['mensaje'] . " - <strong>Estado:</strong> <span style='color: $color;'>$estado</span> <button onclick='cambiarEstado(" . $fila['id'] . ", " . $respondido . ")'>Cambiar estado</button></li>";
}
echo "</ul>";


mysqli_close($con);
?>
<script>
		 function cambiarEstado(id, respondido) {
   
        var xhttp = new XMLHttpRequest();
        
      
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
            
                var boton = document.querySelector("button[data-id='" + id + "']");
                if(respondido == 1) {
                    boton.innerHTML = "Por responder";
                    boton.style.color = "red";
                    boton.setAttribute("data-respondido", "0");
                } else {
                    boton.innerHTML = "Respondido";
                    boton.style.color = "green";
                    boton.setAttribute("data-respondido", "1");
                }
            }
        };
        
      
        var url = "cambiar_estado.php?id=" + id + "&respondido=" + respondido;
        xhttp.open("GET", url, true);
        xhttp.send();
    }
  </script>