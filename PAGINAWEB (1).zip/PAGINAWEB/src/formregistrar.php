<!DOCTYPE html>
<html>

<head>
	<title>Registrar usuario</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../css/registrar.css">
	
</head>

<body>

	<form method="post" action="registro.php" class="form-box">
		<h1 class="form-title">Registrar</h1>
		<input type="text" name="name" placeholder="Nombre completo">
		<input type="password" name="password" placeholder="Contraseña">
		<input type="email" name="email" placeholder="Email">
		<input type="text" name="address" placeholder="Direccion">
		<input type="text" name="phone" placeholder="Phone">
		<input type="submit" name="register">
		<div class="shipAddr">



	</form>
	<?php



	include("registro.php");


	?>
</body>

</html>