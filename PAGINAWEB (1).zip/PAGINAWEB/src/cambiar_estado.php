<?php
include('con_db.php'); 


$id = $_GET['id'];
$respondido = $_GET['respondido'];


$con = conectar();


if($respondido == 1) {
    $sql = "UPDATE contactos SET respondido = 0 WHERE id = $id";
} else {
    $sql = "UPDATE contactos SET respondido = 1 WHERE id = $id";
}


if(mysqli_query($con, $sql)) {
    echo "OK";
} else {
    echo "Error al cambiar el estado: " . mysqli_error($con);
}


mysqli_close($con);
?>
