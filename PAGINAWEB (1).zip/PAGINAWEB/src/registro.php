
<?php 

include("con_db.php");
$con = conectar();
if (isset($_POST['register'])) {
    if (strlen($_POST['name']) >= 1 && strlen($_POST['email']) >= 1) {
		
	    $name = trim($_POST['name']);
		$password = trim($_POST['password']);
	    $email = trim($_POST['email']);
	    $address = trim($_POST['address']);
		$phone = trim($_POST['phone']);
	    $consulta = "INSERT INTO cliente_usuario(nombre, apellido, correo_electronico, direccion, telefono, nombre_de_usuario, contrasena) VALUES ('$name','$password','$email','$address','$phone', '$name', '$password')";
	    $resultado = mysqli_query($con,$consulta);
	    if ($resultado) {
	    	?> 
			<button onclick="window.location.href = '../index.php'"></button>
	    	<h3 class="ok">¡Te has inscripto correctamente!</h3>
           <?php
	    } else {
	    	?> 
	    	<h3 class="bad">¡Ups ha ocurrido un error!</h3>
           <?php
	    }
    }   else {
	    	?> 
	    	<h3 class="bad">¡Por favor complete los campos!</h3>
           <?php
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>

</body>
</html>
