<?php
function conectar() {
    $host = 'cs.ilab.cl'; 
    $user = '2_BD_70'; 
    $pwd = 'benjamin.medinam23'; 
    $bd = '2_BD_70'; 

    try {
        $con = new mysqli($host, $user, $pwd, $bd);
        
        if ($con->connect_error) {
            // Redirigir a la página de error en caso de error de conexión
            header("Location: error.php");
            exit;
        }

        $con->set_charset('utf8'); // Establecer el juego de caracteres
        
        return $con;
    } catch (Exception $e) {
        // Capturar la excepción y mostrar un mensaje de error personalizado al usuario
        echo "Sistema caído: " . $e->getMessage();
        // Puedes hacer más cosas aquí, como registrar el error en un archivo de registro.
        // log_error($e->getMessage());
        return null;
    }
}

// Ejemplo de uso
$conexion = conectar();
if (!$conexion) {
    // No es necesario mostrar un mensaje de error aquí, ya que el usuario será redirigido a la página de error.php
    header("Location: error.php");
    // Solo asegúrate de que la redirección a error.php ocurra correctamente en el bloque catch del código anterior.
    exit;
}

// Resto del código para ejecutar consultas, etc.
?>
