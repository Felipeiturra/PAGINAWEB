<?php


include 'con_db.php';
$con = conectar();


include 'La-carta.php';
$cart = new Cart;


if ($cart->total_items() <= 0) {
    header("Location: index2.php");
}





$query = $con->query("SELECT * FROM cliente_usuario WHERE nombre_de_usuario = '" . $_SESSION['nombre_de_usuario'] . "'");
$custRow = $query->fetch_assoc();

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Pagos </title>
    <meta charset="utf-8">
    
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/pago.css">
  
</head>

<body>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">

                <ul class="nav nav-pills">
                    <li role="presentation"><a href="index2.php">Inicio</a></li>
                    <li role="presentation"><a href="VerCarta.php">Carrito de Compras</a></li>
                    <li role="presentation" class="active"><a href="Pagos.php">Pagar</a></li>

                </ul>
            </div>

            <div class="panel-body">
                <h1>Vista previa de la Orden</h1>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Pricio</th>
                            <th>Cantidad</th>
                            <th>Sub total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($cart->total_items() > 0) {
                    
                            $cartItems = $cart->contents();
                            foreach ($cartItems as $item) {
                                ?>
                                <tr>
                                    <td>
                                        <?php echo $item["name"]; ?>
                                    </td>
                                    <td>
                                        <?php echo '$' . $item["price"] . ' CLP'; ?>
                                    </td>
                                    <td>
                                        <?php echo $item["qty"]; ?>
                                    </td>
                                    <td>
                                        <?php echo '$' . $item["subtotal"] . ' CLP'; ?>
                                    </td>
                                </tr>
                            <?php }
                        } else { ?>
                            <tr>
                                <td colspan="4">
                                    <p>No hay articulos en tu carta......</p>
                                </td>
                            <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3"></td>
                            <?php if ($cart->total_items() > 0) { ?>
                                <td class="text-center"><strong>Total
                                        <?php echo '$' . $cart->total() . ' CLP'; ?>
                                    </strong></td>
                            <?php } ?>
                        </tr>
                    </tfoot>
                </table>
                <div class="shipAddr">
                    <h4>Detalles de envio</h4>
                    <p>
                        <?php echo $custRow['nombre']; ?>
                    </p>
                    <p>
                        <?php echo $custRow['correo_electronico']; ?>
                    </p>
                    <p>
                        <?php echo $custRow['telefono']; ?>
                    </p>
                    <p>
                        <?php echo $custRow['direccion']; ?>
                    </p>
                </div>
                <div class="button-container">
                <a href="index2.php" class="button"><i class="glyphicon glyphicon-menu-left"></i> Continue
                        Comprando</a>
                        <a href="metodoPago.php" class="button">Realizar pedido <i class="glyphicon glyphicon-menu-right"></i></a>
                </div>
            </div>

        </div>
</body>
<div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>

</html>