<!DOCTYPE html>
<html>

<head>
    <title>Agregar productos</title>
    <link rel="stylesheet" type="text/css" href="../css/agregar.css">
    <style>
       body,
        html {
            height: 100%;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            display: flex;
            flex-direction: row;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            /* No Scrollbar */
            overflow: hidden;
            background: linear-gradient(to top, #3b1bf0, #080808);
            /* Degradado azul pastel hacia arriba */
            background-repeat: no-repeat;
            background-size: cover;
        }

        .form-box {
            width: 300px;
            padding: 40px;
            background: black;
            text-align: center;
            border-radius: 15px; /* Esquinas redondeadas */
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.75); /* Sombra */
        }

        .form-title {
            color: rgba(255, 255, 255, 0.75);
            text-transform: uppercase;
            font-weight: 500;
        }

        .form-box input[type="text"],
        .form-box input[type="password"],
        .form-box input[type="number"],
        .form-box textarea,
        .form-box select,
        .form-box button {
            border: 2px solid rgba(255, 255, 255, 0.75);
            background: none;
            display: block;
            margin: 20px auto;
            text-align: center;
            padding: 14px 40px; /* Ajustado el padding para que sea igual al de los botones */
            width: 200px;
            color: white;
            border-radius: 24px;
            outline: none;
            transition: 0.25s;
            cursor: pointer;
        }

        .form-box input[type="text"]:focus,
        .form-box input[type="password"]:focus,
        .form-box input[type="number"]:focus,
        .form-box textarea:focus,
        .form-box select:focus,
        .form-box button:focus {
            width: 280px;
            border-color: #ffffff;
        }

        .color-title {
            color: aliceblue;
        }

        .minimal-button {
            background: rgba(0, 0, 0, 0.75);
        }
    </style>
</head>

<body>

    <form action="agregar.php" method="post" class="form-box">
        <h1 class="color-title">Agregar productos</h1>

        <input type="text" name="name" required placeholder="NOMBRE">

        <input type="number" name="price" min="0" step="0.01" required placeholder="PRECIO">

        <input type="number" name="stock" min="0" required placeholder="STOCK">

        <textarea name="description" placeholder="DESCRIPCIÓN"></textarea>

        <label for="categoria">CATEGORÍA:</label>
        <select name="categoria" id="categoria">
            <option value="1">Camiseta - Ropa superior de algodón o tela similar</option>
            <option value="2">Pantalones - Ropa inferior que cubre las piernas</option>
            <option value="3">Zapatos - Calzado para cubrir los pies</option>
            <option value="4">Calcetines - Prenda de vestir que cubre los pies y parte de la pierna</option>
            <option value="5">Polerones - Prenda de vestir gruesa y abrigada, similar a una sudadera</option>
        </select>

        <button type="submit" class="minimal-button">Agregar</button>

        <button class="minimal-button" onclick="window.location.href = 'menuAdmin.html'">VOLVER</button>
        <button class="minimal-button" onclick="window.location.href = 'formactu.php'">ACTUALIZAR PRODUCTOS</button>
    </form>
</body>

</html>