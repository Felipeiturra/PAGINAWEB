<?php
function conectar() {
    $host = 'cs.ilab.cl'; 
    $user = '2_BD_70'; 
    $pwd = 'benjamin.medinam23'; 
    $bd = '2_BD_70'; 

    $con = new mysqli($host, $user, $pwd, $bd);
    
    if ($con->connect_error) {
        // Redirigir a la página de error en caso de error de conexión
        header("Location: error.php");
        exit;
    }
    
    return $con;
}

// Llamamos a la función conectar para obtener la conexión
$conn = conectar();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Formulario de productos más y menos vendidos</title>
    <style>
        body {
            background: linear-gradient(to top, #3b1bf0, #080808);
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            margin-bottom: 20px;
        }

        button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: #ffffff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #45a049;
        }

        .button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    <?php
    // Consultas SQL para obtener los productos más y menos vendidos
    $query_mas_vendidos = "SELECT p.id_producto, SUM(pv.cantidad) AS total_sold
                          FROM producto p
                          LEFT JOIN producto_has_venta pv ON p.id_producto = pv.id_producto
                          GROUP BY p.id_producto
                          ORDER BY total_sold DESC
                          LIMIT 1";
    $result_mas_vendidos = $conn->query($query_mas_vendidos);
    $row_mas_vendidos = $result_mas_vendidos->fetch_assoc();

    $query_menos_vendidos = "SELECT p.id_producto, SUM(pv.cantidad) AS total_sold
                            FROM producto p
                            LEFT JOIN producto_has_venta pv ON p.id_producto = pv.id_producto
                            GROUP BY p.id_producto
                            ORDER BY total_sold ASC
                            LIMIT 1";
    $result_menos_vendidos = $conn->query($query_menos_vendidos);
    $row_menos_vendidos = $result_menos_vendidos->fetch_assoc();
    ?>
    
    <!-- Formulario de productos más vendidos -->
    <form>
        <h2>Productos más vendidos</h2>
        <label for="mas_vendidos">Producto ID:</label>
        <input type="text" id="mas_vendidos" name="mas_vendidos" value="<?php echo $row_mas_vendidos['id_producto']; ?>">
        <br>
        <label for="cantidad_mas_vendidos">Cantidad Vendida:</label>
        <input type="text" id="cantidad_mas_vendidos" name="cantidad_mas_vendidos"
            value="<?php echo $row_mas_vendidos['total_sold']; ?>">
    </form>

    <!-- Formulario de productos menos vendidos -->
    <form>
        <h2>Productos menos vendidos</h2>
        <label for="menos_vendidos">Producto ID:</label>
        <input type="text" id="menos_vendidos" name="menos_vendidos"
            value="<?php echo $row_menos_vendidos['id_producto']; ?>">
        <br>
        <label for "cantidad_menos_vendidos">Cantidad Vendida:</label>
        <input type="text" id="cantidad_menos_vendidos" name="cantidad_menos_vendidos"
            value="<?php echo $row_menos_vendidos['total_sold']; ?>">
    </form>

    <!-- Botón de volver -->
    <div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
</body>

</html>
