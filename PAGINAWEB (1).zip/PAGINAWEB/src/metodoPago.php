<?php
include 'con_db.php';
$con = conectar();

include 'La-carta.php';
$cart = new Cart;

if ($cart->total_items() <= 0) {
    header("Location: index2.php");
}

$query = $con->query("SELECT * FROM metodo_de_pago");
$metodosDePago = $query->fetch_all(MYSQLI_ASSOC);

$query = $con->query("SELECT * FROM cliente_usuario WHERE nombre_de_usuario = '" . $_SESSION['nombre_de_usuario'] . "'");
$custRow = $query->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Seleccionar Método de Pago</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="../css/metodopago.css">
    <style>
         .button-container {
            margin-top: 20px;
        }
        .button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            cursor: pointer;
        }
        .container {
            padding: 20px;
        }

        .metodo-pago-btn {
            margin-right: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">
                <ul class="nav nav-pills">
                    <li role="presentation"><a href="index2.php">Inicio</a></li>
                    <li role="presentation"><a href="VerCarta.php">Carrito de Compras</a></li>
                    <li role="presentation" class="active"><a href="MetodoPago.php">Seleccionar Metodo de Pago</a></li>
                </ul>
            </div>
            <div class="panel-body">
                <div class="metodos-pago">
                    <h3>Selecciona un Metodo de Pago</h3>
                    <?php
                    if (!empty($metodosDePago)) {
                        foreach ($metodosDePago as $metodo) {
                            echo '<button class="btn btn-primary metodo-pago-btn" onclick="mostrarFormulario(' . $metodo['id_metodo_de_pago'] . ')">' . $metodo['nombre'] . '</button>';
                        }
                    } else {
                        echo 'No hay métodos de pago disponibles.';
                    }
                    ?>
                </div>
                <div id="formulario-pago" style="display: none;">
    <!-- Formulario de pago se mostrará aquí -->
    <h3>Ingrese los datos del metodo de pago</h3>
    <form id="formulario-pago-tarjeta">
    <div class="form-group">
        <label for="nombre_tarjeta">Nombre en la Tarjeta:</label>
        <input type="text" class="form-control" id="nombre_tarjeta" name="nombre_tarjeta" required>
    </div>
    <div class="form-group">
        <label for="numero_tarjeta">Numero de Tarjeta:</label>
        <input type="text" class="form-control" id="numero_tarjeta" name="numero_tarjeta" required>
    </div>
    <div class="form-group">
        <label for="fecha_expiracion">Fecha de Expiracion:</label>
        <input type="text" class="form-control" id="fecha_expiracion" name="fecha_expiracion" placeholder="MM/YY" required>
    </div>
    <div class="form-group">
        <label for="cvv">CVV:</label>
        <input type="text" class="form-control" id="cvv" name="cvv" required>
    </div>
    <div id="notificacion" class="alert alert-success" style="display:none;">El método de pago ha sido guardado exitosamente.</div>

    <!-- Cambiado el tipo de botón a 'button' en lugar de 'submit' -->
    <button type="button" class="btn btn-primary" onclick="mostrarNotificacion()">Guardar metodo de pago</button>
</form>

<script>
    function mostrarNotificacion() {
        // Obtén los valores de los campos
        var nombreTarjeta = document.getElementById("nombre_tarjeta").value;
        var numeroTarjeta = document.getElementById("numero_tarjeta").value;
        var fechaExpiracion = document.getElementById("fecha_expiracion").value;
        var cvv = document.getElementById("cvv").value;

        // Verifica si los campos están completos
        if (nombreTarjeta === '' || numeroTarjeta === '' || fechaExpiracion === '' || cvv === '') {
            // Muestra el mensaje de error si algún campo está vacío
            alert('Completa todos los campos del formulario.');
        } else {
            // Si todos los campos están completos, muestra la notificación
            var notificacion = document.getElementById("notificacion");
            notificacion.style.display = "block";

            // Después de 3 segundos, oculta la notificación
            setTimeout(function() {
                notificacion.style.display = "none";
            }, 3000); // 3000 milisegundos = 3 segundos
        }
    }
</script>

    <div class="panel-body">
                <h1>Vista previa de la Orden</h1>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Pricio</th>
                            <th>Cantidad</th>
                            <th>Sub total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($cart->total_items() > 0) {
                    
                            $cartItems = $cart->contents();
                            foreach ($cartItems as $item) {
                                ?>
                                <tr>
                                    <td>
                                        <?php echo $item["name"]; ?>
                                    </td>
                                    <td>
                                        <?php echo '$' . $item["price"] . ' CLP'; ?>
                                    </td>
                                    <td>
                                        <?php echo $item["qty"]; ?>
                                    </td>
                                    <td>
                                        <?php echo '$' . $item["subtotal"] . ' CLP'; ?>
                                    </td>
                                </tr>
                            <?php }
                        } else { ?>
                            <tr>
                                <td colspan="4">
                                    <p>No hay articulos en tu carta......</p>
                                </td>
                            <?php } ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="3"></td>
                            <?php if ($cart->total_items() > 0) { ?>
                                <td class="text-center"><strong>Total
                                        <?php echo '$' . $cart->total() . ' CLP'; ?>
                                    </strong></td>
                            <?php } ?>
                        </tr>
                    </tfoot>
                </table>
                <div class="shipAddr">
                    <h4>Detalles de envio</h4>
                    <p>
                        <?php echo $custRow['nombre']; ?>
                    </p>
                    <p>
                        <?php echo $custRow['correo_electronico']; ?>
                    </p>
                    <p>
                        <?php echo $custRow['telefono']; ?>
                    </p>
                    <p>
                        <?php echo $custRow['direccion']; ?>
                    </p>
                </div>
                <div class="button-container">
                    <a href="index2.php" class="button"><i class="glyphicon glyphicon-menu-left"></i> Continue
                        Comprando</a>
                        <a href="AccionCarta.php?action=placeOrder" class="button">Realizar pedido <i class="glyphicon glyphicon-menu-right"></i></a>

                </div>
            </div>
   
  
    <script>
        function mostrarFormulario(metodoId) {
            // Mostrar el formulario de pago cuando se selecciona un método de pago
            $('#formulario-pago').show();
            // Aquí puedes personalizar el formulario de pago basado en el método de pago seleccionado
        }
    </script>
</body>
<div class="button-container">
        <a class="button" href="javascript:history.go(-1)">Volver</a>
    </div>
</html>