function continueComprando() {
    // Aquí puedes agregar la funcionalidad que necesitas para continuar comprando
    // Por ejemplo, redirigir a otra página
    window.location.href = "index2.php";
}

function realizarPedido() {
    // Aquí puedes agregar la funcionalidad que necesitas para realizar el pedido
    // Por ejemplo, redirigir a otra página
    window.location.href = "AccionCarta.php?action=placeOrder";
}


